# Recipe Application

This is a command-line application where you can create and display a recipe with ingredients and steps.

## Instructions for Compiling and Running

1. Open **Visual Studio**.

2. **Clone** or **Download** the source code from the GitHub repository.

3. Open the solution file (`RecipeApp.sln`) in Visual Studio.

4. **Build** the solution:
    - Click `Build` from the top menu and then `Build Solution`.

5. **Run** the application:
    - Press `Ctrl + F5` or click `Start Without Debugging`.

6. **Follow the on-screen instructions** to enter the details of your recipe:
    - Number of ingredients
    - Name, quantity, and unit of measurement for each ingredient
    - Number of steps
    - Description for each step

7. After entering all details, the application will display the complete recipe.

---

## GitHub Repository

You can find the source code and further updates on this project in the GitHub repository:

[GitHub Repository Link](https://github.com/yourusername/RecipeApp)
